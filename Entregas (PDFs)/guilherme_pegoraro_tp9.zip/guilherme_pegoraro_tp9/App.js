import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, TextInput, ScrollView, Button, Alert, Linking, View } from 'react-native';
import React, { useState, useEffect } from 'react';
import { Picker } from '@react-native-picker/picker';
import axios from 'axios';
import * as Location from 'expo-location';
import Checkbox from 'expo-checkbox';


export default function App() {
  const [isFormInputValid, setIsFormInputValid] = useState({
    nome: true,
    idade: true,
    email: true,
    telefone: true,
    tipoDeAtendimento: true,
    mensagem: true,
  });
  const [userForm, setUserForm] = useState({
    nome: '',
    idade: '',
    email: '',
    profissional: 'livre Escolha',
    telefone: '',
    assunto: '',
    tipoDeAtendimento: '',
    mensagem: '',
    location: '',
  });
  const [location, setLocation] = useState(null);
  const [isChecked, setIsChecked] = useState(false);
  function sendLocation(value) {
    if (value) {
      setUserForm({
        ...userForm,
        location: location,
      });
      setIsChecked(true);
    } else {
      setUserForm({
        ...userForm,
        location: '',
      });
      setIsChecked(false);
    }
  }

  function validateForm() {
    let validatedFunc = 0;
    const regexEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (regexEmail.test(String(userForm.email).toLowerCase())) {
      validatedFunc += 1;
      setIsFormInputValid(prevState => ({ ...prevState, email: true }));
    } else {
      setIsFormInputValid(prevState => ({ ...prevState, email: false }));
    };

    if (userForm.nome.length > 3) {
      validatedFunc += 1;
      setIsFormInputValid(prevState => ({ ...prevState, nome: true }));
    } else {
      setIsFormInputValid(prevState => ({ ...prevState, nome: false }));
    };

    if (userForm.mensagem.length > 0) {
      validatedFunc += 1;
      setIsFormInputValid(prevState => ({ ...prevState, mensagem: true }));
    } else {
      setIsFormInputValid(prevState => ({ ...prevState, mensagem: false }));
    };

    if (userForm.telefone.replace(/[^0-9]+/g, '').length === 11) {
      validatedFunc += 1;
      setIsFormInputValid(prevState => ({ ...prevState, telefone: true }));
    } else {
      setIsFormInputValid(prevState => ({ ...prevState, telefone: false }));
    };

    if (userForm.idade !== "") {
      validatedFunc += 1;
      setIsFormInputValid(prevState => ({ ...prevState, idade: true }));
    } else {
      setIsFormInputValid(prevState => ({ ...prevState, idade: false }));
    };

    if (userForm.tipoDeAtendimento === "online" || userForm.tipoDeAtendimento === "presencial") {
      validatedFunc += 1;
      setIsFormInputValid(prevState => ({ ...prevState, tipoDeAtendimento: true }));
    } else {
      setIsFormInputValid(prevState => ({ ...prevState, tipoDeAtendimento: false }));
    };
    if (validatedFunc === 6) {
      handleFormSubmit();

    }
  }

  async function handleFormSubmit() {
    axios.defaults.headers.post['Content-Type'] = 'application/json';
    try {
      const response = await axios.post('https://formsubmit.co/ajax/gui.peg@hotmail.com', {
        nome: userForm.nome,
        telefone: userForm.telefone.replace(/[^0-9]+/g, ''),
        email: userForm.email,
        idade: userForm.idade,
        profissional: userForm.profissional,
        tipoDeAtendimento: userForm.tipoDeAtendimento,
        assunto: userForm.assunto,
        mensagem: userForm.mensagem,
        _captcha: false,
      });
      if (response.status === 200) {
        Alert.alert("Formulário enviado com sucesso! logo entraremos em contato para confirmar a consulta")
      }
    } catch (error) {
      Alert.alert("Erro ao enviar formulário! entre em contato para marcar sua consulta, pedimos desculpa pelo transtorno!")
    }
  }

  const handleOpenCalendar = () => {
    Linking.openURL('https://calendar.google.com/calendar/u/0/embed?height=300&wkst=2&bgcolor=%23C0CA33&ctz=America/Sao_Paulo&mode=AGENDA&showTz=0&showCalendars=0&showTabs=0&showPrint=0&showDate=0&showNav=1&showTitle=0&src=cGVkbWFjaGFkbzI3QGdtYWlsLmNvbQ&color=%23039BE5&pli=1');
  };



  useEffect(() => {
    (async () => {

      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setErrorMsg('Permission to access location was denied');
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setLocation(location)
    })();
  }, []);


  const handleOnChangeText = (text, field) => {
    setUserForm({
      ...userForm,
      [field]: text,
    });
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.text}>Cliníca Reverbere - Agendamento de consulta</Text>
      <Text style={styles.label}>Nome</Text>
      <TextInput
        style={[styles.input, isFormInputValid.nome ? null : styles.inputError]}
        value={userForm.nome}
        onChangeText={(text) => handleOnChangeText(text, 'nome')}
      />
      <Text style={styles.label}>Idade</Text>
      <TextInput
        style={[styles.input, isFormInputValid.idade ? null : styles.inputError]}
        value={userForm.idade}
        keyboardType='numeric'
        onChangeText={(text) => handleOnChangeText(text, 'idade')}
      />
      <Text style={styles.label}>Email</Text>
      <TextInput
        style={[styles.input, isFormInputValid.email ? null : styles.inputError]}
        value={userForm.email}
        onChangeText={(text) => handleOnChangeText(text, 'email')}
      />
      <Text style={styles.label}>Telefone</Text>
      <TextInput
        style={[styles.input, isFormInputValid.telefone ? null : styles.inputError]}
        value={userForm.telefone}
        keyboardType='numeric'
        onChangeText={(text) => handleOnChangeText(text, 'telefone')}
      />
      <Text style={styles.label}>Assunto</Text>
      <TextInput
        style={[styles.input]}
        value={userForm.assunto}
        onChangeText={(text) => handleOnChangeText(text, 'assunto')}
      />
      <Text style={styles.label}>Enviar localização para receber direções?</Text>
      <Checkbox style={styles.checkbox} value={isChecked} onValueChange={(value) => {sendLocation(value)}} />
      <Text style={styles.label}>Tipo de Atendimento</Text>
      <Picker
        style={[styles.input, isFormInputValid.tipoDeAtendimento ? null : styles.inputError]}
        selectedValue={userForm.tipoDeAtendimento}
        onValueChange={(itemValue) =>
          setUserForm({ ...userForm, tipoDeAtendimento: itemValue })
        }
      >
        <Picker.Item label="Selecione" value="" />
        <Picker.Item label="Online" value="online" />
        <Picker.Item label="Presencial" value="presencial" />
      </Picker>
      <Text style={styles.label}>Profissional</Text>
      <Picker
        style={[styles.input, isFormInputValid.profissional ? null : styles.inputError]}
        selectedValue={userForm.profissional}
        onValueChange={(itemValue) =>
          setUserForm({ ...userForm, profissional: itemValue })
        }
      >
        <Picker.Item label="Livre Escolha" value="livre Escolha" />
        <Picker.Item label="Gizeli Cunha" value="gizeli cunha" />
        <Picker.Item label="Keli Godoi" value="keli godoi" />
        <Picker.Item label="Ronilda Brusch" value="ronilda brusch" />
      </Picker>
      <Button style={styles.button} title="Abrir Calendário da clínica" onPress={handleOpenCalendar} />
      <Text style={styles.label}>Mensagem</Text>
      <TextInput
        style={[styles.input, { height: 100 }, isFormInputValid.mensagem ? null : styles.inputError]}
        multiline
        value={userForm.mensagem}
        placeholder='Lembre-se de incluir data e hora da consulta em sua mensagem, verifique nosso calendário para horários disponíveis ou deixe em branco para entrarmos em contato.'
        onChangeText={(text) => handleOnChangeText(text, 'mensagem')}
      />
      <View style={styles.buttonsContainer}>
      <Button style={styles.button} title="Agendar Consulta" onPress={validateForm} />
      </View>
    </ScrollView>
  );
};











const styles = StyleSheet.create({
  container: {
    padding: 20,
    marginTop: 30,
    height: '100%',
  },
  label: {
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  inputError: {
    borderColor: 'red',
  },
  errorText: {
    color: 'red',
    marginBottom: 10,
  },
  button: {
    margin: 10,
    padding: 20,
    height: 50,
  },
  buttonsContainer: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    padding: 10,
    marginBottom: 30,
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});