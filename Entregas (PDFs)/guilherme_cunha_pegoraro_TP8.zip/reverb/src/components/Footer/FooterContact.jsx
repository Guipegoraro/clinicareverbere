import React from 'react'

export default function FooterContact() {
  return (
    <View>
      <Text>FooterContact</Text>
    </View>
  )
}