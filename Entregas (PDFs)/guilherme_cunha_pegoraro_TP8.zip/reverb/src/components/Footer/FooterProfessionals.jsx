import React from 'react'

export default function FooterProfessionals() {
  return (
    <View>
      <Text>FooterProfessionals</Text>
    </View>
  )
}