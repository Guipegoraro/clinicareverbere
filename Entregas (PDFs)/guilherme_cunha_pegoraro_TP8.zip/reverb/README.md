## clinicareverbere
Site da clinica de psicologia reverbere - trabalho bloco 1 semestre 2 engenharia de software - Projeto de Bloco
# Link Replit do projeto
https://replit.com/@GuilhermeCunh16/clinicareverbere


# Fazer:

rodapé com contatos endereço formulario de contato e mapas

# IDENTIDADE VISUAL:

FONTES:
Storystone regular para a parte da logo onde diz "reverbere"
link: https://www.dafont.com/storystone.font

Playfair Display para a parte da logo onde diz "clinica de psicologia"
link: https://fonts.google.com/specimen/Playfair+Display

CORES:
principal: #07ade0 (azul)
secundária: #7cc537 (verde)
terciária: #777777 (cinza)


# texto sobre funcionarios
Gizeli Cunha
Psicóloga
CRP 12/13826
– Graduada em psicologia no ano de 2014 pela Faculdade CESUSC – Complexo de ensino superior de Santa Catarina.
– Pós graduanda em Gestão da aprendizagem e educação cognitiva pela Faculdade Unicesumar.
– Atendimentos pela abordagem da terapia cognitivo comportamental.
– Experiência em atendimentos clínicos voltado para a criança a partir de 7 anos, nas demandas relacionadas a dificuldade de adaptação escolar e suas relações em ambientes sociais e familiares.
 – Atendimento a adolescentes e adultos que buscam acolhimento e tratamento psicológico para Transtornos de Humor (depressão e bipolaridade), transtornos de ansiedade generalizada (TAG), Fobias (específicas, social, agorafobia), transtorno de pânico, burnout, estresse pós-traumático, transtornos mentais e comportamentais relacionados ao uso de abusivo de drogas, luto, Transtorno Obsessivo-compulsivo (TOC), entre outras demandas psicológicas.
– Avaliação Psicológica para cirurgia de vasectomia.
Atendimentos para crianças a partir de 7 anos, adolescentes, adultos e idosos.
Atendimento com criança somente presencial e os demais podem ser realizados on-line.

KELI ADRIANA M. GODOI

Psicóloga

CRP 12/12834

– Graduada pela Faculdade CESUSC.
– Atuante na área clínica há seis anos, sob o foco da Psicologia Relacional Sistêmica.
– Atendimentos voltados para adultos que buscam tratamento para transtornos depressivos e relacionados a traumas e estressores.
– Avaliação Psicológica para cirurgia bariátrica e vasectomia.

Atende adultos.

RONILDA ETTER BRUSCH

Psicóloga

CRP 07/21926

– Graduada pela Universidade Feevale-RS.
– Pós-graduanda em Psicologia Positiva e Coaching pela Unileyal.
– Pós graduanda em Psicologia do Trabalho e das organizações pela Estácio.
– Formação voltada à Psicoterapia e controle do Estresse, Transtornos de Ansiedade e Síndrome do Pânico.
– Atendimentos voltados a pacientes que sofrem de Transtorno Obsessivo-Compulsivo (TOC), Transtornos de Humor (depressão e bipolaridade), Fobias (específicas, social, agorafobia) e Transtornos Alimentares.

Atende crianças, adolescentes e adultos.


# IDENTIDADE VISUAL:

FONTES:
Storystone regular para a parte da logo onde diz "reverbere"
link: https://www.dafont.com/storystone.font

Playfair Display para a parte da logo onde diz "clinica de psicologia"
link: https://fonts.google.com/specimen/Playfair+Display

CORES:
principal: #07ade0 (azul)
secundária: #7cc537 (verde)
terciária: #777777 (cinza)

